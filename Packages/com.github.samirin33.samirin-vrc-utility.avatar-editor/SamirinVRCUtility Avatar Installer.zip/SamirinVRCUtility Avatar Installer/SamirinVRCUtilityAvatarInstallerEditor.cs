using System.IO;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
public class SamirinVRCUtilityAvatarInstallerEditor
{
    private const string TargetAssetGUID = "4b4cb93ca6da8f4469e8b6ae18c4742b";
    private const string PackagePath = "Packages/com.github.samirin33.samirin-vrc-utility.avatars";

    private static bool IsPackageAlreadyImported()
    {
        string packageDir = Path.GetFullPath(Path.Combine(Application.dataPath, "..", PackagePath));
        if (Directory.Exists(packageDir))
            return true;

        string manifestPath = Path.Combine(Application.dataPath, "..", "Packages", "manifest.json");
        if (File.Exists(manifestPath))
        {
            try
            {
                string manifestJson = File.ReadAllText(manifestPath);
                if (manifestJson.Contains("com.github.samirin33.samirin-vrc-utility.avatars"))
                    return true;
            }
            catch { /* ignore */ }
        }

        return false;
    }

    private class SamirinVRCUtilityAvatarInstallerAssetPostprocessor : AssetPostprocessor
    {
        private static void OnPostprocessAllAssets(
            string[] importedAssets,
            string[] deletedAssets,
            string[] movedAssets,
            string[] movedFromAssetPaths)
        {
            foreach (string path in importedAssets)
            {
                if (path.EndsWith("SamirinVRCUtilityAvatarInstallerEditor.cs"))
                {
                    EditorApplication.delayCall += () =>
                    {
                        if (IsPackageAlreadyImported())
                            return;

                        string targetPath = AssetDatabase.GUIDToAssetPath(TargetAssetGUID);
                        if (!string.IsNullOrEmpty(targetPath))
                        {
                            string fullPath = Path.GetFullPath(Path.Combine(Application.dataPath, "..", targetPath));
                            if (File.Exists(fullPath))
                            {
                                AssetDatabase.ImportPackage(fullPath, false);
                            }
                        }
                    };
                    break;
                }
            }
        }
    }
}
#endif